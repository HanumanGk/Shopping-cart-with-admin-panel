<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
#frontend Routes...............................
Route::get('/',[ 
    'uses' => 'HomeController@index',
    'as' => 'Homepage'
]);

Route::get('/product_by_category/{category_id}',[
    'uses' =>'HomeController@show_product_by_category',
    'as' =>'product-by-category'
]);
Route::get('/product_by_manufracture/{manufracture_id}',[
    'uses' =>'HomeController@show_product_by_manufracture',
    'as' =>'product-by-manufracture'
]);
Route::get('/view_product/{product_id}',[
    'uses' =>'HomeController@product_details_by_id',
    'as' =>'view_product'
]);





#Cart Routes Are Here.................................
Route::post('/add-to-cart',[
    'uses' =>'CartController@add_to_cart',
    'as' =>'add-to-cart'
]);
Route::get('/show-cart',[
    'uses' => 'CartController@show_cart',
    'as' =>'show-cart'
]);
Route::get('/delete-to-cart/{rowId}',[
    'uses' => 'CartController@delete_to_cart',
    'as' => 'delete-to-cart'
]);
Route::post('/update-cart',[
    'uses' =>'CartController@update_cart',
    'as' => 'update-cart'
]);


#Checkout routes.......................



Route::get('/strip_payment',[
    'uses' =>'CheckoutController@stripe_payment',
    'as' => 'strip_payment'
]);




Route::get('/login-check',[
    'uses' =>'CheckoutController@login_check',
    'as' => 'login-check'
]);
Route::post('/cutomer_registration',[
    'uses' =>'CheckoutController@customer_registration',
    'as' => 'cutomer_registration'
]);
Route::get('/checkout',[
    'uses' =>'CheckoutController@checkout',
    'as' =>'checkout'
]);
Route::post('/save-shipping-details',[
    'uses' =>'CheckoutController@save_shipping_details',
    'as' => 'save-shipping-details'
]);
#login & Logout routes........

Route::post('/cutomer_login',[
    'uses' =>'CheckoutController@customer_login',
    'as' => 'cutomer_login'
]);
Route::get('/customer_logout',[
    'uses' =>'CheckoutController@customer_logout',
    'as' => 'customer_logout'
]);


Route::get('/payment',[
    'uses' =>'CheckoutController@payment',
    'as' => 'payment'
]);
Route::post('/order_place',[
    'uses' =>'CheckoutController@order_place', 
    'as' => 'order_place'
]);


Route::get('/manage_order',[
    'uses' =>'CheckoutController@manage_order',
    'as' => 'manage_order'
]);
Route::get('/view_order/{order_id}',[
    'uses' =>'CheckoutController@view_order',
    'as' => 'view_order'
]);
Route::get('/payment_paypal',[
    'uses' =>'CheckoutController@payment_paypal',
    'as' => 'payment_paypal'
]);


#PaypalPayment
// Route::get('payment', 'PaymentController@index')->name('payment');
// Route::post('payment', 'PaymentController@payment')->name('payment');
// Route::get('returnurl', 'PaymentController@returnurl')->name('returnurl');





























#Backend Routes................................
#SuperAdminController.....
Route::get('/logout',[
    'uses' => 'SuperAdminController@logout',
    'as' => 'logout'
]);
Route::get('/dashboard',[
    'uses' => 'SuperAdminController@index',
     'as' => 'dashboard'
]);
#AdminController.....


Route::get('/admin',[
    'uses' => 'adminController@admin',
    'as' => 'admin'
]);
Route::post('/admin_dashboard',[
    'uses' => 'adminController@dashboard',
    'as' => '/admin_dashboard'
]);


#Category ............
Route::get('/add-category',[
    'uses' => 'CategoryController@index',
    'as' => 'add-category'
]);
Route::get('/all-category', [
    'uses' => 'CategoryController@all_category',
    'as' => 'all-category'
]);
Route::post('/save-category',[
    'uses' => 'CategoryController@save_category',
    'as' => 'save-category'
]);
Route::get('/unactive-category/{category_id}',[
    'uses' => 'CategoryController@unactive_category',
    'as' => 'unactive-category'
]);
Route::get('/active-category/{category_id}',[
    'uses' => 'CategoryController@active_category',
    'as' => 'active-category'
]);
Route::get('/edit-category/{category_id}',[
    'uses' => 'CategoryController@edit_category',
    'as' => 'edit-category'
]);
Route::post('/update-category/{category_id}',[
    'uses' =>'CategoryController@update_category',
    'as' =>'update-category'
]);
Route::get('/delete-category/{category_id}',[
    'uses' =>'CategoryController@delete_category',
    'as' =>'delete-category'
]);


#Manufracture..................
Route::get('/add-manufracture',[
    'uses' => 'ManufractureController@index',
    'as' => 'add-manufracture'
]);
Route::post('/save-manufracture',[
    'uses' => 'ManufractureController@save_manufracture',
    'as' => 'save-manufracture'
]);
Route::get('/all-manufracture', [
    'uses' => 'ManufractureController@all_manufracture',
    'as' => 'all-manufracture'
]);
Route::get('/delete-manufracture/{manufracture_id}',[
    'uses' =>'ManufractureController@delete_manufracture',
    'as' =>'delete-manufracture'
]);
Route::get('/unactive-manufracture/{manufracture_id}',[
    'uses' => 'ManufractureController@unactive_manufracture',
    'as' => 'unactive-manufracture'
]);
Route::get('/active-manufracture/{manufracture_id}',[
    'uses' => 'ManufractureController@active_manufracture',
    'as' => 'active-manufracture'
]);
Route::get('/edit-manufracture/{manufracture_id}',[
    'uses' => 'ManufractureController@edit_manufracture',
    'as' => 'edit-manufracture'
]);
Route::post('/update-manufracture/{manufracture_id}',[
    'uses' =>'ManufractureController@update_manufracture',
    'as' =>'update-manufracture'
]);



#Products............
Route::get('/add-products',[
    'uses' => 'ProductsController@index',
    'as' => 'add-products'
]);
Route::post('/save-product',[
    'uses' => 'ProductsController@save_product',
    'as' => 'save-product'
]);
Route::get('/all-products',[
    'uses' => 'ProductsController@all_products',
    'as' => 'all-products'
]);
Route::get('/unactive-product/{product_id}',[
    'uses' => 'ProductsController@unactive_product',
    'as' => 'unactive-product'
]);
Route::get('/active-product/{product_id}',[
    'uses' => 'ProductsController@active_product',
    'as' => 'active-product'
]);
Route::get('/delete-product/{product_id}',[
    'uses' => 'ProductsController@delete_product',
    'as' => 'delete-product'
]);


#Slider............................
Route::get('/add-slider',[
    'uses'=> 'SliderController@index',
    'as' =>'add-slider'
]);
Route::post('/save-slider',[
    'uses'=> 'SliderController@save_slider',
    'as' =>'save-slider'
]);
Route::get('/all-slider',[
    'uses'=> 'SliderController@all_slider',
    'as' =>'all-slider'
]);
Route::get('/unactive-slider/{slider_id}',[
    'uses' => 'SliderController@unactive_slider',
    'as' => 'unactive-slider'
]);
Route::get('/active-slider/{slider_id}',[
    'uses' => 'SliderController@active_slider',
    'as' => 'active-slider'
]);
Route::get('/delete-slider/{slider_id}',[
    'uses' => 'SliderController@delete_slider',
    'as' => 'delete-slider'
]);


