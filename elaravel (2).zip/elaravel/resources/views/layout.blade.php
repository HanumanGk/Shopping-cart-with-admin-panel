
@include('includes.header')
	<?php 
    $all_published_slider=DB::table('tbl_slider')
    ->where('publication_status',1)
    ->get(); 

?>  
<section id="slider"><!--slider-->
    <div class="">
      <div class="row"> 

         <div id="carousel-example-generic" class="carousel slide " data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    @foreach( $all_published_slider as $v_slider )
                        <li data-target="#carousel-example-generic" data-slide-to="{{ $loop->index }}" class="{{ $loop->first ? 'active' : '' }}"></li>
                    @endforeach
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                    @foreach( $all_published_slider as $v_slider )
                        <div class="item {{ $loop->first ? ' active' : '' }}" >
							{{-- <img src="{{ $v_slider->slider_image }}"> --}}
							<div class="col-sm-6">
									<h1><span>E</span>-SHOPPER</h1>
									<h2>Free E-Commerce Template</h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
									<button type="button" class="btn btn-default get">Get it now</button>
								</div>
								<div class="col-sm-6">
									<img src="{{ URL::to($v_slider->slider_image)}}" class="girl img-responsive" alt="" />
									<img src="frontend/images/home/pricing.png"  class="pricing" alt="" />
								</div>
                        </div>
                    @endforeach
                </div>
                <!-- Controls -->
                <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

         </div>
     </div>
 </section>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<?php
								$all_published_category = DB::table('tbl_category')
														->where('publication_satus',1)
														->get()
							?>
							@foreach($all_published_category as $v_category)
							
							<div class="panel panel-default">
								<div class="panel-heading">
								<h4 class="panel-title">
									<a href="{{URL::to('/product_by_category/'.$v_category->category_id)}}">{{ $v_category->category_name }}</a></h4>
								</div>
							</div>
							@endforeach
						
							</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Brands</h2>
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
										<?php
										$all_published_manufracture = DB::table('tbl_manufracture')
																->where('publication_status',1)
																->get()
									?>
							        @foreach($all_published_manufracture as $v_manufracture)

									<li><a href="{{URL::to('/product_by_manufracture/'.$v_manufracture->manufracture_id)}}">
										 <span class="pull-right">(50)</span>{{ $v_manufracture->manufracture_name }}</a></li>
								@endforeach
								</ul>
							</div>
						</div><!--/brands_products-->
						
						<div class="price-range"><!--price-range-->
							<h2>Price Range</h2>
							<div class="well text-center">
								 <input type="text" class="span2" value="" data-slider-min="0" data-slider-max="600" data-slider-step="5" data-slider-value="[250,450]" id="sl2" ><br />
								 <b class="pull-left">$ 0</b> <b class="pull-right">$ 600</b>
							</div>
						</div><!--/price-range-->
						
						<div class="shipping text-center"><!--shipping-->
							<img src="frontend/images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
				@yield('content')

			</div>
		</div>
	</section>
	
@include('includes.footer')
</body>
</html>