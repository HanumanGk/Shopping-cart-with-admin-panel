


@extends('admin_layout')
@section('admin_content')


            <div class="col-md-3"></div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i> Brands Table</div>
                  <p class="alert alert-success">
                        <?php    
                          $message  = Session::get('message');
                          if($message)
                          {
                              echo $message;
                              Session::put('message' , null);
      
                          }
                          ?> 
                          </p>
                <div class="card-body">
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>manufracture Name</th>
                        <th>Discription</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    @foreach($all_manufracture_info as $v_manufracture)
                    <tbody>
                      <tr>
                        <td>{{ $v_manufracture->manufracture_id }}</td>
                        <td>{{ $v_manufracture->manufracture_name }}</td>
                        <td>{{ $v_manufracture->manufracture_description }}</td>
                        <td>
                          @if($v_manufracture->publication_status==1)
                        <span class="badge badge-success">Active</span>
                        @else 
                        <span class="badge badge-danger">Inactive</span>
                          @endif
                        </td>
                        <td>
                          @if($v_manufracture->publication_status==1)
                            <a class="text-danger" href="{{URL::to('/unactive-manufracture/' 
                            .$v_manufracture->manufracture_id)}}">
                              <i class="fa fa-thumbs-down"></i>
                            </a>
                            @else
                            <a class="text-success" href="{{URL::to('/active-manufracture/' 
                            .$v_manufracture->manufracture_id)}}">
                                <i class="fa fa-thumbs-up"></i>
                              </a>
                              @endif
                            <a class="text-success" href="{{URL::to('/edit-manufracture/' 
                            .$v_manufracture->manufracture_id)}}">
                                <i class="fa fa-edit"></i>
                            </a>  
                            <span>   </span>
                            <a class="text-success" href="{{URL::to('/delete-manufracture/' 
                            .$v_manufracture->manufracture_id)}}" id="delete">
                                <i class="fa fa-trash"></i>
                            </a>                        
                        </td>
                      </tr>
                        </tbody>

                        @endforeach
                  </table>
                  {{ $all_manufracture_info->render()}}
                </div>
              </div>
            </div>

@endsection