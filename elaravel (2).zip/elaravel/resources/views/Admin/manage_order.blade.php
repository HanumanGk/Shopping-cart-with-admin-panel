


@extends('admin_layout')
@section('admin_content')


            <div class="col-md-3"></div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i>Order</div>
                <div class="card-body">
                    {{-- <p class="alert alert-success"> --}}
                        <?php    
                          $message  = Session::get('message');
                          if($message)
                          {
                              echo $message;
                              Session::put('message' , null);
      
                          }
                          ?> 
                          {{-- </p> --}}
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Order Total</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    @foreach($all_order_info as $v_order)
                    <tbody>
                      <tr>
                        <td>{{ $v_order->order_id }}</td>
                        <td>{{ $v_order->customer_name }}</td>
                        <td>{{ $v_order->order_total }}</td>
                        <td>{{ $v_order->order_status }}</td>

                        <td class="text-center">
{{--                          @if($v_category->publication_satus==1)
                        <span class="badge badge-success">Active</span>
                        @else 
                        <span class="badge badge-danger">Inactive</span>
                          @endif
                        </td> --}}
                        {{-- <td>
                          @if($v_category->publication_satus==1) 
                            <a class="text-danger" href="{{URL::to('/unactive-/' 
                            .$v_order->order_id)}}">
                              <i class="fa fa-thumbs-down"></i>
                            </a> 
                            @else 
                            <a class="text-success" href="{{URL::to('/active-order/' 
                            .$v_order->order_id)}}">
                                <i class="fa fa-thumbs-up"></i>
                              </a> 
                              @endif --}}
                            <a class="text-success" href="{{URL::to('/view_order/' 
                            .$v_order->order_id)}}">
                                <i class="fa fa-edit"></i>
                            </a>  
                            {{-- <span>   </span>
                            <a class="text-success" href="{{URL::to('/delete-/' 
                            .$v_order->order_id)}}" id="delete">
                                <i class="fa fa-trash"></i>
                            </a>                         --}}
                        </td> 
                      </tr>
                        </tbody>

                        @endforeach
                  </table>

                  {{$all_order_info->render()}}
                  
                </div>
              </div>
            </div>

@endsection