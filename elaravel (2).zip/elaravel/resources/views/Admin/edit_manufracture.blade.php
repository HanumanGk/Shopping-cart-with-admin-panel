



@extends('admin_layout')
@section('admin_content')



{{-- <div class="container"> --}}
        {{-- <div class="animated fadeIn"> --}}
                    {{-- <div class="row"> --}}
            <div class="col-md-3"></div>

            <div class="col-md-6">
              <div class="card">
                <div class="card-header">
                    <strong>Update</strong> Manufracture</div>
                    
                    <div class="card-body">
                <form class="form-horizontal" action="{{URL::to('/update-manufracture/' .$manufracture_info->manufracture_id)}}" method="post" >
                   {{ csrf_field() }}
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="text-input">Update Manufracture</label>
                      <div class="col-md-9">
                      <input class="form-control" type="text" name="manufracture_name" placeholder="Name" 
                      value="{{ $manufracture_info->manufracture_name }}">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="textarea-input">Description</label>
                      <div class="col-md-9">
                        <textarea class="form-control" id="textarea-input" name="manufracture_description" rows="9" >
                            {{ $manufracture_info->manufracture_description }}</textarea>
                      </div>
                    </div>
                   
                    <div class="card-footer">
                            <button class="btn btn-sm btn-primary" type="submit">
                              <i class="fa fa-dot-circle-o"></i> Update Manufracture</button>
                          </div>
                  </form>
                </div>
                
              </div>
              
            </div>
              
          {{-- </div> --}}
          <!-- /.row-->
        {{-- </div> --}}
      {{-- </div> --}}


@endsection