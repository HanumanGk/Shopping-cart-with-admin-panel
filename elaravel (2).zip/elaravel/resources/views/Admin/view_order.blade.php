@extends('admin_layout')




@section('admin_content')



<div class="container-fluid">
        <div class="animated fadeIn">
          <div class="row">
              <div class="col-md-1"></div>
            <div class="col-lg-5">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i>Customer Details</div>
                <div class="card-body">
                  <table class="table table-responsive-sm table-striped">
                    <thead>
                      <tr>
                        <th>Username</th>
                        <th>Mobile</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                      {{-- <td>{{$order_by_id->customer_name}}</td> --}}
                        {{-- <td>{{$order_by_id->mobile_number}}</td> --}}
                      </tr>
                    </tbody>
                  </table>
                  <ul class="pagination">
                    <li class="page-item">
                      <a class="page-link" href="#">Prev</a>
                    </li>
                    <li class="page-item active">
                      <a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">Next</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- /.col-->
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i>Shipping Details</div>
                <div class="card-body">
                  <table class="table table-responsive-sm table-striped">
                    <thead>
                      <tr>
                        <th>Username</th>
                        <th>Address</th>
                        <th>Mobile</th>
                        <th>Email</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        {{-- <td>{{$order_by_id->shipping_first_name}}</td> --}}
                        {{-- <td>{{$order_by_id->shipping_address}}</td> --}}
                        {{-- <td>{{$order_by_id->shipping_mobile_number}}</td> --}}
                        {{-- <td>{{$order_by_id->shipping_email}}</td> --}}

                      </tr>
                    </tbody>
                  </table>
                  <ul class="pagination">
                    <li class="page-item">
                      <a class="page-link" href="#">Prev</a>
                    </li>
                    <li class="page-item active">
                      <a class="page-link" href="#">1</a>
                    </li>
                    
                    <li class="page-item">
                      <a class="page-link" href="#">Next</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- /.col-->
          </div>
          <div class="row">
              <div class="col-md-1"></div>
            <div class="col-lg-11">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i>Order Details</div>
                <div class="card-body">
                  <table class="table table-responsive-sm table-striped">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Product Sales Quantity</th>
                        <th>Product Sub Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        {{-- <td>{{$order_by_id->product_id}}</td> --}}
                        {{-- <td>{{$order_by_id->product_name}}</td> --}}
                        {{-- <td>{{$order_by_id->product_price}}</td> --}}
                        {{-- <td>{{$order_by_id->product_sales_quantity}}</td> --}}
                        {{-- <td>{{$order_by_id->shipping_first_name}}</td> --}}

                      </tr>
                      
                    </tbody>
                  </table>
                  <nav>
                    <ul class="pagination">
                      <li class="page-item">
                        <a class="page-link" href="#">Prev</a>
                      </li>
                      <li class="page-item active">
                        <a class="page-link" href="#">1</a>
                      
                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
            <!-- /.col-->
          </div>
          <!-- /.row-->
        </div>
      </div>


@endsection