


@extends('admin_layout')
@section('admin_content')


            <div class="col-md-1"></div>
            <div class="col-lg-10">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i> Simple Table</div>
                <div class="card-body">
                    <p class="alert alert-success">
                        <?php    
                          $message  = Session::get('message');
                          if($message)
                          {
                              echo $message;
                              Session::put('message' , null);
      
                          }
                          ?> 
                          </p>
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>Slider ID</th>
                        <th>Slider Image</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    @foreach($all_slider_info as $v_slider)
                    <tbody>
                       <tr> 
                        <td>{{ $v_slider->slider_id }}</td>
                        <td><img src="{{URL::to($v_slider->slider_image)}}" style="height:80px; width:250px;"></td>
                        <td>
                          @if($v_slider->publication_status==1)
                        <span class="badge badge-success">Active</span>
                        @else 
                        <span class="badge badge-danger">Inactive</span>
                          @endif
                        </td>
                        <td>
                          @if($v_slider->publication_status==1)
                            <a class="text-danger" href="{{URL::to('/unactive-slider/' 
                            .$v_slider->slider_id)}}">
                              <i class="fa fa-thumbs-down"></i>
                            </a>
                            @else
                            <a class="text-success" href="{{URL::to('/active-slider/' 
                            .$v_slider->slider_id)}}">
                                <i class="fa fa-thumbs-up"></i>
                              </a>
                              @endif
                            <a class="text-success" href="{{URL::to('/delete-slider/' 
                            .$v_slider->slider_id)}}" id="delete">
                                <i class="fa fa-trash"></i>
                            </a>                        
                        </td>
                      </tr>
                        </tbody>

                        @endforeach
                  </table>
                  <ul class="pagination">
                    <li class="page-item">
                      <a class="page-link" href="#">Prev</a>
                    </li>
                    <li class="page-item active">
                      <a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">Next</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

@endsection