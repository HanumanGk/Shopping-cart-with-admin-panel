


@extends('layout')


@section('content')




        
<form action="/purchase" method="POST">
    <!-- Note that the amount is in paise = 50 INR -->
    <script
        src="https://checkout.razorpay.com/v1/checkout.js"
        data-key="<YOUR_KEY_ID>"
        data-amount="5000"
        data-buttontext="Pay with Razorpay"
        data-name="Merchant Name"
        data-description="Purchase Description"
        data-image="https://your-awesome-site.com/your_logo.jpg"
        data-prefill.name="Harshil Mathur"
        data-prefill.email="support@razorpay.com"
        data-theme.color="#F37254"
    ></script>
    <input type="hidden" value="Hidden Element" name="hidden">
    </form>






    <button id="rzp-button1">Pay</button>
   <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
   <script>
   var options = {
       "key": "YOUR_KEY_ID",
       "amount": "2000", // 2000 paise = INR 20
       "name": "Merchant Name",
       "description": "Purchase Description",
       "image": "/your_logo.png",
       "handler": function (response){
           alert(response.razorpay_payment_id);
       },
       "prefill": {
           "name": "Harshil Mathur",
           "email": "harshil@razorpay.com"
       },
       "notes": {
           "address": "Hello World"
       },
       "theme": {
           "color": "#F37254"
       }
   };
   var rzp1 = new Razorpay(options);
   
   document.getElementById('rzp-button1').onclick = function(e){
       rzp1.open();
       e.preventDefault();
   }



   var razorpay = new Razorpay(...); // as before

razorpay.once('ready', function() {
  // razorpay.methods.emi_plans has list of EMI-supported banks, and respective interest rates
  console.log(razorpay.methods.emi_plans);

  // razorpay.methods.netbanking contains list of all banks and bank-codes
  console.log(razorpay.methods.netbanking);
})
   </script>
  @endsection