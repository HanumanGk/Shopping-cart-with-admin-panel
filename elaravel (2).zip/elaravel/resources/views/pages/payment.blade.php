@extends('layout')


@section('content')



<section id="cart_items">
    <div class="col-md-9">
        <div class="breadcrumbs">
            <ol class="breadcrumb">
              <li><a href="#">Home</a></li>
              <li class="active">Shopping Cart</li>
            </ol>
        </div>
        <div class="table-responsive cart_info">
            <?php $content = Cart::content();
                // echo "<pre>";
                // print_r($content);
                // echo "</pre>";

            ?>
            <table class="table table-condensed">
                <thead>
                    <tr class="cart_menu">
                        <td class="image">Item</td>
                        <td class="description">Name</td>
                        <td class="price">Price</td>
                        <td class="quantity">Quantity</td>
                        <td class="total">Total</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    @foreach($content as $v_contents)
                    <tr>
                        <td class="cart_product">
                        <a href=""><img src="{{URL::to($v_contents->options->image)}}" alt=""
                             height="80px" width="80px"></a>
                        </td>
                        <td class="cart_description">
                        <h4><a href="">{{$v_contents->name}}</a></h4>
                            {{-- <p>Web ID: 1089772</p> --}}
                        </td>
                        <td class="cart_price">
                            <p>₹ {{$v_contents->price}}.00</p>
                        </td>
                        <td class="cart_quantity">
                            <div class="cart_quantity_button">
                            <form method="post" action="{{URL::to('/update-cart')}}">
                                {{csrf_field()}}
                                <input class="cart_quantity_input" type="text" name="qty" 
                                value="{{$v_contents->qty}}" autocomplete="off" size="2">
                                <input type="hidden" name="rowId" value="{{$v_contents->rowId}}">
                                <input class="btn btn-sm btn-default" type="submit" name="submit" 
                                value="Update">
                            </form>
                            </div>
                        </td>
                        <td class="cart_total">
                            <p class="cart_total_price">₹ {{$v_contents->total}}.00</p>
                        </td>
                        <td class="cart_delete">
                        <a class="cart_quantity_delete" href="{{URL::to('/delete-to-cart/'.$v_contents->rowId)}}"><i class="fa fa-times"></i></a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    <form action="{{url('order_place')}}" method="post">
            {{csrf_field()}}
        {{-- <div class="paymentWrap">
            <div class="btn-group paymentBtnGroup btn-group-justifed" data-toggle="buttons">
                <label for="" class="btn paymentMethod active" checked>
                    <div class="method visa">
                        <img src="{{URL::to('../public/frontend/images/shop/handcash.png')}}"
                         alt="" height="80px" width="150px">
                    </div>
                    <input type="radio" name="payment_gateway" value="handcash">
                </label>
                <label for="" class="btn paymentMethod ">
                    <div class="method mastercard">
                        <img src="{{URL::to('../public/frontend/images/shop/paypal-logo.png')}}" 
                        alt="" height="80px" width="150px">
                    </div>
                    <input type="radio" name="payment_gateway" value="paypal">
                </label>
                <label for="" class="btn paymentMethod ">
                    <div class="method amex">
                        <img src="{{URL::to('../public/frontend/images/shop/payza.png')}}"
                         alt="" height="80px" width="150px">
                    </div>
                    <input type="radio" name="payment_gateway" value="bcash">
                </label>
                <label for="" class="btn paymentMethod ">
                    <div class="method ez-cash">
                    <img src="{{URL::to('../public/frontend/images/shop/bcash.png')}}" 
                        alt="" height="80px" width="150px">
                    </div>
                    <input type="radio" name="payment_gateway" value="payza">
                </label>
                <label for="" class=" ">
                    <input type="submit" value="submit" class="btn btn-success">
                    </label>
            </div>
        </div> --}}

        <input type="radio" name="payment_method" value="handcash">Hand Cash<br>
        <input type="radio" name="payment_method" value="cart">Cart<br>
        <input type="radio" name="payment_method" value="paypal">Paypal<br>
        <input type="submit" value="Submit" class="btn btn-success">


        </form>
    </div>
</section> <!--/#cart_items-->


@endsection