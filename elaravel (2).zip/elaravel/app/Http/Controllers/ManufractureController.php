<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Pagination\Paginator;

session_start();

class ManufractureController extends Controller
{
    public function index()
    {
        $this->AdminAuthCheck();
        return view('admin.add_manufracture');
    }
    public function save_manufracture(Request $request)
    {
        $data = array();
          $data['manufracture_id'] =  $request->manufracture_id;
          $data['manufracture_name'] =  $request->manufracture_name;
          $data['manufracture_description'] =  $request->manufracture_description;
          $data['publication_status'] =  $request->publication_status;
          

        DB::table('tbl_manufracture')->insert($data);
        Session::put('message', 'Manufracture Added Successefully!!!!!!');
        return Redirect()->route('add-manufracture');
    }

    public function all_manufracture()
    {
        $this->AdminAuthCheck();
        $all_manufracture_info=DB::table('tbl_manufracture')->get();
        $all_manufracture_info=DB::table('tbl_manufracture')->paginate(6);
        $manage_manufracture=view('admin.all_manufracture')
            ->with('all_manufracture_info',$all_manufracture_info);

        return view('admin_layout')
            ->with('admin.all_manufracture', $manage_manufracture);
    }

    public function delete_manufracture($manufracture_id)
    {
        DB::table('tbl_manufracture')
            ->where('manufracture_id', $manufracture_id)
            ->delete();
        Session::get('message' ,'Manufracture Deleted Successfully.!!!!!!');
        return Redirect()->route('all-manufracture');
    }

    public function unactive_manufracture($manufracture_id)
    {
        DB::table('tbl_manufracture')
            ->where('manufracture_id', $manufracture_id)
            ->update(['publication_status' => 0]);
            Session::put('message', 'Manufracture Unactive Successefully!!!!!!');
            return Redirect()->route('all-manufracture');
    }
    public function active_manufracture($manufracture_id)
    {
        DB::table('tbl_manufracture')
            ->where('manufracture_id', $manufracture_id)
            ->update(['publication_status' => 1]);
            Session::put('message', 'Manufracture Active Successefully!!!!!!');
            return Redirect()->route('all-manufracture');
    }

    public function edit_manufracture($manufracture_id)
    {
        $this->AdminAuthCheck();
        $manufracture_info = DB::table('tbl_manufracture')
                        ->where('manufracture_id' , $manufracture_id)
                        ->first();

            $manufracture_info=view('admin.edit_manufracture')
            ->with('manufracture_info',$manufracture_info);

        return view('admin_layout')
            ->with('admin.edit_manufracture', $manufracture_info);
        // return view('Admin.edit_manufracture');
    }
    public function update_manufracture(Request $request, $manufracture_id)
    {
        $data = array();
        $data['manufracture_name'] = $request->manufracture_name;
        $data['manufracture_description'] = $request->manufracture_description;

            DB::table('tbl_manufracture')
                ->where('manufracture_id', $manufracture_id)
                ->update($data);

              Session::get('message', 'Manufracture Updated Successfully..!!!!');
              return Redirect()->route('all-manufracture');  


    }

    public function AdminAuthCheck()
    {
        $admin_id = Session::get('admin_id');
        if($admin_id){
            return;
        }else{
            return Redirect()->route('admin')->send();
        }
    }
}
