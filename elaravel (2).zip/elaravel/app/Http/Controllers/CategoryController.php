<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Pagination\Paginator;

session_start();

class CategoryController extends Controller
{
    public function index()
    {
        $this->AdminAuthCheck();
        return view('Admin.add_category');

    }
    
    public function all_category()
    {
        $this->AdminAuthCheck();
        $all_category_info=DB::table('tbl_category')->get();
        $all_category_info=DB::table('tbl_category')->paginate(10);

                // ->paginate(3);
                // ->orderBy('sequence','asc');

        $manage_category=view('admin.all_category')
            ->with('all_category_info',$all_category_info);
        return view('admin_layout')
            

            ->with('admin.all_category', $manage_category);


            // ->with('admin.all_category', ['user', $users]);
            

    }

    public function save_category(Request $request)
    {
        $data = array();
          $data['category_id'] =  $request->category_id;
          $data['category_name'] =  $request->category_name;
          $data['category_description'] =  $request->category_description;
          $data['publication_satus'] =  $request->publication_satus;
          

        DB::table('tbl_category')->insert($data);
        Session::put('message', 'Category Added Successefully!!!!!!');
        return Redirect()->route('add-category');


    }

    public function unactive_category($category_id)
    {
        DB::table('tbl_category')
            ->where('category_id', $category_id)
            ->update(['publication_satus' => 0]);
            Session::put('message', 'Category Unactive Successefully!!!!!!');
            return Redirect()->route('all-category');
    }

    public function active_category($category_id)
    {
        DB::table('tbl_category')
            ->where('category_id', $category_id)
            ->update(['publication_satus' => 1]);
            Session::put('message', 'Category Active Successefully!!!!!!');
            return Redirect()->route('all-category');
    }

    public function edit_category($category_id)
    {
        $this->AdminAuthCheck();
        $category_info = DB::table('tbl_category')
                        ->where('category_id' , $category_id)
                        ->first();

            $category_info=view('admin.edit_category')
            ->with('category_info',$category_info);

        return view('admin_layout')
            ->with('admin.edit_category', $category_info);
        // return view('Admin.edit_category');
    }

    public function update_category(Request $request, $category_id)
    {
        $data = array();
        $data['category_name'] = $request->category_name;
        $data['category_description'] = $request->category_description;

            DB::table('tbl_category')
                ->where('category_id', $category_id)
                ->update($data);

              Session::get('message', 'Category Updated Successfully..!!!!');
              return Redirect()->route('all-category');  


    }

    public function delete_category($category_id)
    {
        DB::table('tbl_category')
            ->where('category_id', $category_id)
            ->delete();
        Session::get('message' ,'Category Deleted Successfully.!!!!!!');
        return Redirect()->route('all-category');
    }


    public function AdminAuthCheck()
    {
        $admin_id = Session::get('admin_id');
        if($admin_id){
            return;
        }else{
            return Redirect()->route('admin')->send();
        }
    }
}
