<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use Session;
class HomeController extends Controller
{
    public function index()
    {
        // $this->AdminAuthCheck();
        $all_published_product=DB::table('tbl_products')
                    ->join('tbl_category','tbl_products.category_id','=','tbl_category.category_id')
                    ->join('tbl_manufracture','tbl_products.manufracture_id','=','tbl_manufracture.manufracture_id')                    
                    ->select('tbl_products.*','tbl_category.category_name','tbl_manufracture.manufracture_name')
                    ->where('tbl_products.publication_status',1)
                    ->limit(9)
                    ->get();
        // echo "<pre>";
        // print_r($all_product_info);
        // echo "</pre>";



        $manage_published_product=view('pages.home')
            ->with('all_published_product',$all_published_product);
        return view('layout')
            ->with('pages.home', $manage_published_product);
        // return view('pages.home');
    }

    public function show_product_by_category($category_id)
    {
        $category_by_product_published=DB::table('tbl_products')
                    ->join('tbl_category','tbl_products.category_id','=','tbl_category.category_id')
                    ->select('tbl_products.*','tbl_category.category_name')
                    ->where('tbl_category.category_id',$category_id)
                    ->where('tbl_products.publication_status',1)
                    ->limit(9)
                    ->get();

        $manage_category_by_product=view('pages.category_by_product')
            ->with('category_by_product_published',$category_by_product_published);
        return view('layout')
            ->with('pages.category_by_product', $manage_category_by_product);
    }


    public function show_product_by_manufracture($manufracture_id)
    {
        $manufracture_by_product_published=DB::table('tbl_products')
                    // ->join('tbl_category','tbl_products.category_id','=','tbl_category.category_id')
                    ->join('tbl_manufracture','tbl_products.manufracture_id','=','tbl_manufracture.manufracture_id')                    
                    ->select('tbl_products.*','tbl_manufracture.manufracture_name')
                    ->where('tbl_manufracture.manufracture_id',$manufracture_id)
                    ->where('tbl_products.publication_status',1)
                    ->limit(9)
                    ->get();

        $manage_manufracture_by_product=view('pages.product_by_manufracture')
            ->with('manufracture_by_product_published',$manufracture_by_product_published);
        return view('layout')
            ->with('pages.product_by_manufracture', $manage_manufracture_by_product);
    }
    
    public function product_details_by_id($product_id)
    {
        $product_details_by_id=DB::table('tbl_products')
                    ->join('tbl_category','tbl_products.category_id','=','tbl_category.category_id')
                    ->join('tbl_manufracture','tbl_products.manufracture_id','=','tbl_manufracture.manufracture_id')                    
                    ->select('tbl_products.*','tbl_category.category_name','tbl_manufracture.manufracture_name')
                    ->where('tbl_products.product_id',$product_id)
                    ->where('tbl_products.publication_status',1)
                    ->get();

        $manage_product_details=view('pages.product_details')
            ->with('product_details_by_id',$product_details_by_id);
        return view('layout')
            ->with('pages.product_details', $manage_product_details);
    }

}
