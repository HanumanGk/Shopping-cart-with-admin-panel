<?php $__env->startSection('admin_content'); ?>


<div class="col-md-3"></div>

<div class="col-md-6">
    <div class="card">
    <div class="card-header">
        <strong>Add</strong> Product</div>

        <p class="alert alert-success">
                <?php    
                               $message  = Session::get('message');
                               if($message)
                               {
                                   echo $message;
                                   Session::put('message' , null);
           
                               }
                               ?> 
                               </p>
        <div class="card-body">
    <form class="form-horizontal" action="/elaravel/public/save-product" method="post" 
    enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="text-input">Add Products</label>
            <div class="col-md-9">
            <input class="form-control" type="text" name="products_name" placeholder="Name" required>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="select1">Category Name</label>
            <div class="col-md-9">
                <select class="form-control" id="select1" name="category_id">
                <option>Select Category</option>
                <?php
                    $all_published_category = DB::table('tbl_category')
                                            ->where('publication_satus',1)
                                            ->get()
                ?>
                <?php $__currentLoopData = $all_published_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
                <option value="<?php echo e($v_category->category_id); ?>"><?php echo e($v_category->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="select1">Manufacture Name</label>
            <div class="col-md-9">
                <select class="form-control" id="select1" name="manufracture_id">
                <option>Select Manufacture</option>
                <?php
                    $all_published_manufracture = DB::table('tbl_manufracture')
                                            ->where('publication_status',1)
                                            ->get()
                ?>
                <?php $__currentLoopData = $all_published_manufracture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_manufracture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($v_manufracture->manufracture_id); ?>"><?php echo e($v_manufracture->manufracture_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="textarea-input">Product Short Description </label>
            <div class="col-md-9">
            <textarea class="form-control" id="textarea-input"
                name="product_short_description" rows="4" placeholder="Content.." required></textarea>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="textarea-input">Product Long Description </label>
            <div class="col-md-9">
            <textarea class="form-control" id="textarea-input"
                name="product_long_description" rows="6" placeholder="Content.." required></textarea>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="text-input">Product Price</label>
            <div class="col-md-9">
            <input class="form-control" type="text" name="product_price" placeholder="Name" required>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="file-input">Image File</label>
            <div class="col-md-9">
                <input id="file-input" type="file" name="product_image">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="text-input">Product size</label>
            <div class="col-md-9">
            <input class="form-control" type="text" name="product_size" placeholder="Size" required>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label" for="text-input">Product color</label>
            <div class="col-md-9">
            <input class="form-control" type="text" name="product_color" placeholder="Color" required>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-md-3 col-form-label">Publication Status</label>
            <div class="col-md-9 col-form-label">
            <div class="form-check form-check-inline mr-1">
                <input class="form-check-input"  type="checkbox" value="1" name="publication_status">
                <label class="form-check-label" ></label>
            </div>
            </div>
        </div>
        
        <div class="card-footer">
                <button class="btn btn-sm btn-primary" type="submit">
                    <i class="fa fa-dot-circle-o"></i> Submit</button>
                <button class="btn btn-sm btn-danger" type="reset">
                    <i class="fa fa-ban"></i> Reset</button>
                </div>
        </form>
    </div>
    
    </div>
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>