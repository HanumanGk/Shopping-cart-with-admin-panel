<!DOCTYPE html>


<html lang="en">
  <head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
    <meta name="author" content="Łukasz Holeczek">
    <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
    <title>Admin Panel of E-shopper Website</title>
    <!-- Icons-->
    <link href="https://unpkg.com/@coreui/coreui/dist/css/coreui.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.1.0/css/flag-icon.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css" rel="stylesheet">
    <!-- Main styles for this application-->
    <link href="css/style.css" rel="stylesheet">
    <link href="vendors/pace-progress/css/pace.min.css" rel="stylesheet">
  </head>
  <body class="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
    <header class="app-header navbar">
      <button class="navbar-toggler sidebar-toggler d-lg-none mr-auto" type="button" data-toggle="sidebar-show">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
        <img class="navbar-brand-full" src="frontend/images/home/logo.png" width="89" height="25" alt="CoreUI Logo">
        <img class="navbar-brand-minimized" src="frontend/images/home/logo.png" width="30" height="30" alt="CoreUI Logo">
      </a>
      <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button" data-toggle="sidebar-lg-show">
        <span class="navbar-toggler-icon"></span>
      </button>
      <ul class="nav navbar-nav d-md-down-none">
        
      </ul>
      <ul class="nav navbar-nav ml-auto">
        
        <li class="nav-item d-md-down-none">
          <a class="nav-link" href="#">
            <i class="icon-list"></i>
          </a>
        </li>
        <li class="nav-item d-md-down-none">
          <a class="nav-link" href="#">
            <i class="icon-location-pin"></i>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
            <?php echo e(Session::get('admin_name')); ?>

          </a>
          <div class="dropdown-menu dropdown-menu-right">
            <div class="divider"></div>
            <a class="dropdown-item" href="#">
              <i class="fa fa-shield"></i>Profile</a>
            <a class="dropdown-item" href="<?php echo e(URL::to('/logout')); ?>">
              <i class="fa fa-lock"></i> Logout</a>
          </div>
        </li>
      </ul>
      <button class="navbar-toggler aside-menu-toggler d-md-down-none" type="button" data-toggle="aside-menu-lg-show">
        <span class="navbar-toggler-icon"></span>
      </button>
      <button class="navbar-toggler aside-menu-toggler d-lg-none" type="button" data-toggle="aside-menu-show">
        <span class="navbar-toggler-icon"></span>
      </button>
    </header>
    <div class="app-body">
      <div class="sidebar">
        <nav class="sidebar-nav">
          <ul class="nav">
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="nav-icon icon-speedometer"></i> Dashboard
                <span class="badge badge-primary">NEW</span>
              </a>
            </li>
            <li class="nav-item nav-dropdown">
            <a class="nav-link nav-dropdown-toggle">
                <i class="nav-icon icon-puzzle"></i>Category</a>
              <ul class="nav-dropdown-items">
                <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('all-category')); ?>">
                    <i class="nav-icon icon-"></i>All Category</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('add-category')); ?>">
                        <i class="nav-icon icon-"></i>Add Category</a>
                    </li>
              </ul>
            </li>
            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle">
                    <i class="nav-icon icon-puzzle"></i>Manufacture</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('all-manufracture')); ?>">
                          <i class="nav-icon icon-"></i>All Manufacture</a>
                      </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('add-manufracture')); ?>">
                      <i class="nav-icon icon-"></i>Add Manufacture</a>
                  </li>
                </ul>
              </li>

              <li class="nav-item nav-dropdown">
                  <a class="nav-link nav-dropdown-toggle" >
                      <i class="nav-icon icon-puzzle"></i> Products
                      
                <span class="badge badge-primary">NEW</span>
                  </a>
                  <ul class="nav-dropdown-items">
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('add-products')); ?>">
                        <i class="nav-icon icon-puzzle"></i>Add Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('all-products')); ?>">
                          <i class="nav-icon icon-puzzle"></i>All Products</a>
                      </li>
                  </ul>
                </li>

                <li class="nav-item nav-dropdown">
                  <a class="nav-link nav-dropdown-toggle">
                     <i class="nav-icon icon-puzzle"></i>Slider 
                  </a>
                  <ul class="nav-dropdown-items">
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('add-slider')); ?>">
                        <i class="nav-icon icon-puzzle"></i>Add Slider</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('all-slider')); ?>">
                          <i class="nav-icon icon-puzzle"></i>All Slider</a>
                      </li>
                  </ul>
                </li>
            
            
            
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('manage_order')); ?>">
                  <i class="nav-icon icon-puzzle"></i>Manage Order</a>
              </li>
            

          </ul>
        </nav>
        <button class="sidebar-minimizer brand-minimizer" type="button"></button>
      </div>
     



<?php echo $__env->yieldContent('admin_content'); ?>



      <aside class="aside-menu">
        <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#timeline" role="tab">
              <i class="icon-list"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#messages" role="tab">
              <i class="icon-speech"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#settings" role="tab">
              <i class="icon-settings"></i>
            </a>
          </li>
        </ul>
        <!-- Tab panes-->
        
      </aside>
    </div>
    <footer class="app-footer">

      <div class="ml-auto">
        <span>Powered by</span>
        <a href="#">HanumanGk &copy; 2018</a>
      </div>
    </footer>
    <!-- CoreUI and necessary plugins-->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.4.0/perfect-scrollbar.min.js"></script>
    <script src="https://unpkg.com/@coreui/coreui/dist/js/coreui.min.js"></script>

    <!-- Plugins and scripts required by this view-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.js"></script>
    
    <script src="js/main.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.js"></script>
    <script>
      $(document).on("click" ,"#delete" , function(e){
        e.preventDefault();
        var link = $(this).attr("href");
        bootbox.confirm("Are You Want To Delete!!!", function(confirmed){
          if(confirmed){
            window.location.href = link;
          };
        });
      });
    </script>
  </body>
</html>