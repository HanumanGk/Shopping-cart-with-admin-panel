<?php $__env->startSection('admin_content'); ?>




        
                    
            <div class="col-md-3"></div>

            <div class="col-md-6">
              <div class="card">
                <div class="card-header">
                    <strong>Update</strong> Category</div>
                    <p class="alert alert-success">
     <?php    
                    $message  = Session::get('message');
                    if($message)
                    {
                        echo $message;
                        Session::put('message' , null);

                    }
                    ?> 
                    </p>
                    <div class="card-body">
                <form class="form-horizontal" action="/elaravel/public/update-category" method="post" >
                   <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="text-input">Update Category</label>
                      <div class="col-md-9">
                        <input class="form-control" type="text" name="category_name" placeholder="Name" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="textarea-input">Description</label>
                      <div class="col-md-9">
                        <textarea class="form-control" id="textarea-input" name="category_description" rows="9" placeholder="Content.." required></textarea>
                      </div>
                    </div>
                   
                    <div class="card-footer">
                            <button class="btn btn-sm btn-primary" type="submit">
                              <i class="fa fa-dot-circle-o"></i> Update Category</button>
                          </div>
                  </form>
                </div>
                
              </div>
              
            </div>
              
          
          <!-- /.row-->
        
      


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>