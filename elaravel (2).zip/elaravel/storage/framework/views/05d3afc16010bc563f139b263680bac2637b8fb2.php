<?php $__env->startSection('admin_content'); ?>


            <div class="col-md-3"></div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i> Brands Table</div>
                  <p class="alert alert-success">
                        <?php    
                          $message  = Session::get('message');
                          if($message)
                          {
                              echo $message;
                              Session::put('message' , null);
      
                          }
                          ?> 
                          </p>
                <div class="card-body">
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>manufracture Name</th>
                        <th>Discription</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    <?php $__currentLoopData = $all_manufracture_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_manufracture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                      <tr>
                        <td><?php echo e($v_manufracture->manufracture_id); ?></td>
                        <td><?php echo e($v_manufracture->manufracture_name); ?></td>
                        <td><?php echo e($v_manufracture->manufracture_description); ?></td>
                        <td>
                          <?php if($v_manufracture->publication_status==1): ?>
                        <span class="badge badge-success">Active</span>
                        <?php else: ?> 
                        <span class="badge badge-danger">Inactive</span>
                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($v_manufracture->publication_status==1): ?>
                            <a class="text-danger" href="<?php echo e(URL::to('/unactive-manufracture/' 
                            .$v_manufracture->manufracture_id)); ?>">
                              <i class="fa fa-thumbs-down"></i>
                            </a>
                            <?php else: ?>
                            <a class="text-success" href="<?php echo e(URL::to('/active-manufracture/' 
                            .$v_manufracture->manufracture_id)); ?>">
                                <i class="fa fa-thumbs-up"></i>
                              </a>
                              <?php endif; ?>
                            <a class="text-success" href="<?php echo e(URL::to('/edit-manufracture/' 
                            .$v_manufracture->manufracture_id)); ?>">
                                <i class="fa fa-edit"></i>
                            </a>  
                            <span>   </span>
                            <a class="text-success" href="<?php echo e(URL::to('/delete-manufracture/' 
                            .$v_manufracture->manufracture_id)); ?>" id="delete">
                                <i class="fa fa-trash"></i>
                            </a>                        
                        </td>
                      </tr>
                        </tbody>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                  <?php echo e($all_manufracture_info->render()); ?>

                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>