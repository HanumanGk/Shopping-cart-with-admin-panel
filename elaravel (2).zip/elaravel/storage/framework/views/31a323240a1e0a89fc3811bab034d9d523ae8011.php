<?php $__env->startSection('admin_content'); ?>


            <div class="col-md-3"></div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i>Order</div>
                <div class="card-body">
                    
                        <?php    
                          $message  = Session::get('message');
                          if($message)
                          {
                              echo $message;
                              Session::put('message' , null);
      
                          }
                          ?> 
                          
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Order Total</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    <?php $__currentLoopData = $all_order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                      <tr>
                        <td><?php echo e($v_order->order_id); ?></td>
                        <td><?php echo e($v_order->customer_name); ?></td>
                        <td><?php echo e($v_order->order_total); ?></td>
                        <td><?php echo e($v_order->order_status); ?></td>

                        <td class="text-center">

                        
                            <a class="text-success" href="<?php echo e(URL::to('/view_order/' 
                            .$v_order->order_id)); ?>">
                                <i class="fa fa-edit"></i>
                            </a>  
                            
                        </td> 
                      </tr>
                        </tbody>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>

                  <?php echo e($all_order_info->render()); ?>

                  
                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>