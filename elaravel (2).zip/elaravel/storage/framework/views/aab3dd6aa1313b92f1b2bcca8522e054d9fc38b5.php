<?php $__env->startSection('admin_content'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>