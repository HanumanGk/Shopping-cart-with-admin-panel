<?php $__env->startSection('admin_content'); ?>


            <div class="col-md-2"></div>
            <div class="col-lg-10">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i> Product Table</div>
                <div class="card-body">
                    <p class="alert alert-success">
                        <?php    
                          $message  = Session::get('message');
                          if($message)
                          {
                              echo $message;
                              Session::put('message' , null);
      
                          }
                          ?> 
                          </p>
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        
                        <th>Product Image</th>
                        <th>Product Price</th>
                        <th>Category Name</th>
                        <th>Manufacture Name</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    <?php $__currentLoopData = $all_product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                       <tr> 
                        <td><?php echo e($v_product->product_id); ?></td>
                        <td><?php echo e($v_product->products_name); ?></td>
                        
                        <td><img src="<?php echo e(URL::to($v_product->product_image)); ?>" style="height:80px; width:80px;"></td>
                        <td><?php echo e($v_product->product_price); ?></td>
                        <td><?php echo e($v_product->category_name); ?></td>
                        <td><?php echo e($v_product->manufracture_name); ?></td>

                        <td>
                          <?php if($v_product->publication_status==1): ?>
                        <span class="badge badge-success">Active</span>
                        <?php else: ?> 
                        <span class="badge badge-danger">Inactive</span>
                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($v_product->publication_status==1): ?>
                            <a class="text-danger" href="<?php echo e(URL::to('/unactive-product/' 
                            .$v_product->product_id)); ?>">
                              <i class="fa fa-thumbs-down"></i>
                            </a>
                            <?php else: ?>
                            <a class="text-success" href="<?php echo e(URL::to('/active-product/' 
                            .$v_product->product_id)); ?>">
                                <i class="fa fa-thumbs-up"></i>
                              </a>
                              <?php endif; ?>
                            <a class="text-success" href="<?php echo e(URL::to('/edit-product/' 
                            .$v_product->product_id)); ?>">
                                <i class="fa fa-edit"></i>
                            </a>  
                            <span>   </span>
                            <a class="text-success" href="<?php echo e(URL::to('/delete-product/' 
                            .$v_product->product_id)); ?>" id="delete">
                                <i class="fa fa-trash"></i>
                            </a>                        
                        </td>
                      </tr>
                        </tbody>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                  <?php echo e($all_product_info->render()); ?>

                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>