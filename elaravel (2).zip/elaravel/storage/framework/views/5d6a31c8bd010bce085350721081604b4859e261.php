<?php $__env->startSection('admin_content'); ?>


            <div class="col-md-3"></div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-align-justify"></i> Simple Table</div>
                <div class="card-body">
                  <table class="table table-responsive-sm">
                    <thead>
                      <tr>
                        <th>Username</th>
                        <th>Date registered</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Samppa Nori</td>
                        <td>2012/01/01</td>
                        <td>Member</td>
                        <td>
                          <span class="badge badge-success">Active</span>
                        </td>
                        <td>
                            <a class="text-success">
                                <i class="fa fa-edit"></i>
                            </a>  
                            <span>   </span>
                            <a class="text-success">
                                <i class="fa fa-trash"></i>
                            </a>                        
                        </td>
                      </tr>
                        </tbody>
                  </table>
                  <ul class="pagination">
                    <li class="page-item">
                      <a class="page-link" href="#">Prev</a>
                    </li>
                    <li class="page-item active">
                      <a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">Next</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>