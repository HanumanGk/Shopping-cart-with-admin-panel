<?php $__env->startSection('admin_content'); ?>




        
                    
            <div class="col-md-3"></div>

            <div class="col-md-6">
              <div class="card">
                <div class="card-header">
                    <strong>Add</strong> Category</div>
                    <p class="alert alert-success">
     <?php    
                    $message  = Session::get('message');
                    if($message)
                    {
                        echo $message;
                        Session::put('message' , null);

                    }
                    ?> 
                    </p>
                    <div class="card-body">
                <form class="form-horizontal" action="/elaravel/public/save-category" method="post" >
                   <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="text-input">Add Category</label>
                      <div class="col-md-9">
                        <input class="form-control" type="text" name="category_name" placeholder="Name" required>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="textarea-input">Description</label>
                      <div class="col-md-9">
                        <textarea class="form-control" id="textarea-input" name="category_description" rows="9" placeholder="Content.." required></textarea>
                      </div>
                    </div>
                   
                   
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label">Publication Status</label>
                      <div class="col-md-9 col-form-label">
                        <div class="form-check form-check-inline mr-1">
                          <input class="form-check-input"  type="checkbox" value="1" name="publication_satus">
                          <label class="form-check-label" ></label>
                        </div>
                      </div>
                    </div>
                    
                    <div class="card-footer">
                            <button class="btn btn-sm btn-primary" type="submit">
                              <i class="fa fa-dot-circle-o"></i> Submit</button>
                            <button class="btn btn-sm btn-danger" type="reset">
                              <i class="fa fa-ban"></i> Reset</button>
                          </div>
                  </form>


                </div>
                
              </div>
              
            </div>
              
          
          <!-- /.row-->
        
      


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>