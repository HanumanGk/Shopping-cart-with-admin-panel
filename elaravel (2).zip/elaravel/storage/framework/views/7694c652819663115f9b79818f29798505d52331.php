<?php $__env->startSection('content'); ?>



<section id="cart_items">
    <div class="col-md-9">
        <div class="breadcrumbs">
            <ol class="breadcrumb">
              <li><a href="#">Home</a></li>
              <li class="active">Shopping Cart</li>
            </ol>
        </div>
        <div class="table-responsive cart_info">
            <?php $content = Cart::content();
                // echo "<pre>";
                // print_r($content);
                // echo "</pre>";

            ?>
            <table class="table table-condensed">
                <thead>
                    <tr class="cart_menu">
                        <td class="image">Item</td>
                        <td class="description">Name</td>
                        <td class="price">Price</td>
                        <td class="quantity">Quantity</td>
                        <td class="total">Total</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="cart_product">
                        <a href=""><img src="<?php echo e(URL::to($v_contents->options->image)); ?>" alt=""
                             height="80px" width="80px"></a>
                        </td>
                        <td class="cart_description">
                        <h4><a href=""><?php echo e($v_contents->name); ?></a></h4>
                            
                        </td>
                        <td class="cart_price">
                            <p>₹ <?php echo e($v_contents->price); ?>.00</p>
                        </td>
                        <td class="cart_quantity">
                            <div class="cart_quantity_button">
                            <form method="post" action="<?php echo e(URL::to('/update-cart')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input class="cart_quantity_input" type="text" name="qty" 
                                value="<?php echo e($v_contents->qty); ?>" autocomplete="off" size="2">
                                <input type="hidden" name="rowId" value="<?php echo e($v_contents->rowId); ?>">
                                <input class="btn btn-sm btn-default" type="submit" name="submit" 
                                value="Update">
                            </form>
                            </div>
                        </td>
                        <td class="cart_total">
                            <p class="cart_total_price">₹ <?php echo e($v_contents->total); ?>.00</p>
                        </td>
                        <td class="cart_delete">
                        <a class="cart_quantity_delete" href="<?php echo e(URL::to('/delete-to-cart/'.$v_contents->rowId)); ?>"><i class="fa fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <form action="<?php echo e(url('order_place')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        

        <input type="radio" name="payment_method" value="handcash">Hand Cash<br>
        <input type="radio" name="payment_method" value="cart">Cart<br>
        <input type="radio" name="payment_method" value="paypal">Paypal<br>
        <input type="submit" value="Submit" class="btn btn-success">


        </form>
    </div>
</section> <!--/#cart_items-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>