<?php $__env->startSection('content'); ?>


<section id="cart_items">
		<div class="col-md-9">

			<div class="register-req">
				<p>Please fill the form..................</p>
			</div><!--/register-req-->

			<div class="shopper-informations">
				<div class="row">
					<div class="col-sm-12 clearfix">
						<div class="bill-to">
							<p>Shipping Details</p>
							<div class="form-one">
                            <form method="POST" action="<?php echo e(url('/save-shipping-details')); ?>">
                                <?php echo e(csrf_field()); ?>

									<input type="text" name="shipping_email" placeholder="Email*">
									<input type="text" name="shipping_first_name" placeholder="First Name *">
									<input type="text" name="shipping_last_name" placeholder="Last Name *">
									<input type="text" name="shipping_address" placeholder="Address *">
                                    <input type="text" name="shipping_mobile_number" placeholder="Mobile Number *">
									<input type="text" name="shipping_city" placeholder="City *">
									<input type="submit" value="Done" class="btn btn-default">
                                    
								</form>
							</div>
							
						</div>
					</div>
										
				</div>
			</div>

		</div>
	</section> <!--/#cart_items-->

	



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>